//
//  Constants.swift
//  FundsApp
//
//  Created by Bargav on 12/11/21.
//

import Foundation

let LISTPAGEURL = "https://api.github.com/repositories"
