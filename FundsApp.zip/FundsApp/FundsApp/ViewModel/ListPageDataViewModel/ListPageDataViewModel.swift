//
//  ListPageDataViewModel.swift
//  FundsApp
//
//  Created by Bargav on 12/11/21.
//

import Foundation

class ListPageDataViewModel{
    
    var listPageData:ListPageDataModel?
    
    init(listPageData:ListPageDataModel){
        self.listPageData = listPageData
    }
}
