//
//  ListPageViewController.swift
//  FundsApp
//
//  Created by Bargav on 12/11/21.
//

import UIKit

class ListPageViewController: UIViewController {
    
    @IBOutlet weak var listDetailsTableView: UITableView!
    
    var listPageDataViewModel:[ListPageDataViewModel]?
    
    let cellId = "ListDetailsTableViewCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setUpListPage()
    }
}

extension ListPageViewController{
    
    func setUpListTableView(cellId:String) {
        // Do any additional setup after loading the view.
        let nib = UINib(nibName:cellId, bundle: nil)
        self.listDetailsTableView.register(nib, forCellReuseIdentifier: cellId)
        self.listDetailsTableView.isScrollEnabled = true
        self.listDetailsTableView.showsVerticalScrollIndicator = false
        self.listDetailsTableView.showsHorizontalScrollIndicator = false
        self.listDetailsTableView.backgroundColor = .white
        self.listDetailsTableView.separatorStyle = .singleLineEtched
        self.listDetailsTableView.delegate = self
        self.listDetailsTableView.dataSource = self
        self.listDetailsTableView.allowsSelection = true
        self.listDetailsTableView.isUserInteractionEnabled = true
        self.listDetailsTableView.estimatedRowHeight = 260
        self.listDetailsTableView.rowHeight = UITableView.automaticDimension
        //self.dropDownTableView.tableFooterView = UIView()
    }
    func setUpListPage(){
        setUpListTableView(cellId: cellId)
        loadListPageData()
    }
    func loadListPageData(){
        WebService.sharedInstance.getListPageDetails { listPageResponseData, error in
            if error == nil{
                guard let listPageResponseDataUnWrapped = listPageResponseData else {
                    return
                }
                guard !listPageResponseDataUnWrapped.isEmpty else{return}
                self.listPageDataViewModel = listPageResponseDataUnWrapped.map{return ListPageDataViewModel(listPageData: $0)}
                DispatchQueue.main.async {
                    print(self.listPageDataViewModel?.count)
                    self.listDetailsTableView.reloadData()
                }
            }
            
            //request time out - Web Service Error
            else{
                //Inside Background Thread - do something here that will be taking time
                
                guard let error = error?.localizedDescription else{
                    //Inside Main Thread - Update your UI here
                    DispatchQueue.main.async{
                        let alert = UIAlertController(title: "UnKnown Error", message: "Please contact Admin or Retry", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Ok", style: .destructive, handler: { (action: UIAlertAction!) in
                            print("Handle Ok logic here")
                        }))
                        self.present(alert, animated: true, completion: nil)
                    }
                    return
                }
                
                //Inside Main Thread - Update your UI here
                DispatchQueue.main.async{
                    let alert = UIAlertController(title: "Web Service Error", message: "Web Service Down OR\nWeb Service Not Connected\nConnection Problem \nPlease Contact Admin OR \nRetry\n Error:\(error)", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive, handler: { (action: UIAlertAction!) in
                        print("Handle Ok logic here")
                    }))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
}

extension ListPageViewController:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.listPageDataViewModel?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as! ListDetailsTableViewCell
        cell.configureCell(cell: cell, rowNo: indexPath.row, listPageData: self.listPageDataViewModel ?? [])
        return cell
    }
}

extension ListPageViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
