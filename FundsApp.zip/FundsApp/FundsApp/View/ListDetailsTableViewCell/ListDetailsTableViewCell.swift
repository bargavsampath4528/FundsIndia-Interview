//
//  ListDetailsTableViewCell.swift
//  FundsApp
//
//  Created by Bargav on 13/11/21.
//

import UIKit

class ListDetailsTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var thumbNailImageView: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}

extension ListDetailsTableViewCell{
    func configureCell(cell:ListDetailsTableViewCell,rowNo:Int,listPageData:[ListPageDataViewModel]){
        
        cell.tag = listPageData[rowNo].listPageData?.id ?? 0
        cell.selectionStyle = .none
        cell.titleLabel.text = listPageData[rowNo].listPageData?.title
        cell.descriptionLabel.text = listPageData[rowNo].listPageData?.description
        guard let urlString = listPageData[rowNo].listPageData?.thumbNailImageURL else{return}
        
        cell.thumbNailImageView.layer.cornerRadius = cell.thumbNailImageView.frame.width/2
        
        if let url = URL(string: urlString){
            self.thumbNailImageView.load(url: url, cellTag: cell.tag, listDataId: listPageData[rowNo].listPageData?.id ?? 0)
        }
    }
}
