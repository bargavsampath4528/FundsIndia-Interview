//
//  WebService.swift
//  FundsApp
//
//  Created by Bargav on 12/11/21.
//

import Foundation

class WebService{
    
    static let sharedInstance = WebService()
    
    var images = NSCache<NSString,NSData>()
    
    func getListPageDetails(completion:@escaping([ListPageDataModel]?,Error?)->()){
        
        let urlString = LISTPAGEURL

        if let url = URL(string: urlString){
            var request = URLRequest(url: url)
            request.httpMethod = "GET"
            
            URLSession.shared.dataTask(with: request) {(data, response, error) in
                guard let data = data else{
                    if error == nil {
                        print(error?.localizedDescription ?? "Unknown error")
                    }
                    return completion(nil,error)
                }
                if let response = response as? HTTPURLResponse{
                    guard (200...299) ~= response.statusCode else{
                        print("status code - \(response.statusCode)")
                        print(response)
                        return
                    }
                }
                do{
                    let json = try JSONSerialization.jsonObject(with: data, options: []) as? [[String:Any]]
                    print(json)
                    print(json?.count)
                    
                    var listDataModel = [ListPageDataModel]()
                    
                    _ = json?.compactMap({ data in
                        let name = data["name"] as? String
                        let description = data["description"] as? String
                        let id = data["id"] as? Int
                        
                        let ownerDict = data["owner"] as? [String:Any]
                        
                        _ = ownerDict?.filter({data in
                            if data.key == "avatar_url"{
                                let thumbNailImageURLString = data.value as? String
                                let listData = ListPageDataModel(title: name ?? "", description: description ?? "", thumbNailImageURL:thumbNailImageURLString ?? "", id: id ?? 0)
                                listDataModel.append(listData)
                                return true
                            }
                            else{
                                return false
                            }
                        })
                    })
                    print(listDataModel)
                    completion(listDataModel,nil)
                    
                }catch let error{
                    print("JSON serialization failed",error.localizedDescription)
                    completion(nil,error)
                }
            }.resume()
        }
    }
}
