//
//  ListPageDataModel.swift
//  FundsApp
//
//  Created by Bargav on 12/11/21.
//

import Foundation

class ListPageDataModel {
    
    var title:String?
    var description:String?
    var thumbNailImageURL:String?
    var id:Int?
    
    //dependency injection
    init(title:String,description:String,thumbNailImageURL:String,id:Int){
        self.title = title
        self.description = description
        self.thumbNailImageURL = thumbNailImageURL
        self.id = id
    }
}
