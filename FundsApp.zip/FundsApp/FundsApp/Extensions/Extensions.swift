//
//  Extensions.swift
//  FundsApp
//
//  Created by Bargav on 14/11/21.
//

import Foundation
import UIKit

extension UIImageView{
    
    func load(url: URL, cellTag: Int, listDataId: Int) {
        
        if let imageData = WebService.sharedInstance.images.object(forKey: url.absoluteString as NSString){
            print("Using cache Image")
            let data = imageData as Data
            if let image = UIImage(data: data) {
                DispatchQueue.main.async {
                    if cellTag == listDataId{
                        print(true)
                        self.image = image
                    }
                }
            }
        }
        
        else{
            DispatchQueue.global().async { [weak self] in
                if let data = try? Data(contentsOf: url) {
                    WebService.sharedInstance.images.setObject(data as NSData, forKey: url.absoluteString as NSString)
                    print("Using downloaded image")
                    if let image = UIImage(data: data) {
                        DispatchQueue.main.async {
                            if cellTag == listDataId{
                                print(true)
                                self?.image = image
                            }
                        }
                    }
                }
            }
        }
    }
}
